#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;

const int N = 10000;
vector<int> E[N + 1];
int n, a[N + 1], ans;

void dfs(int u, int p)
{
	ans = max(ans, a[u]);
	for (int v : E[u])
		if (v != p)
		{
			a[v] += a[u];
			dfs(v, u);
		}
}

int main()
{
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	for (int i = 1; i <= n - 1; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		E[u].push_back(v);
		E[v].push_back(u);
	}
	dfs(1, 0);
	printf("%d", ans);
}