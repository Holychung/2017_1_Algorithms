#include<cstdio>
#include<algorithm>
#include<vector>
#include<stack>
using namespace std;

void tarjan_scc(int u, const vector<vector<int>> &E, vector<int> &dfn, vector<int> &low, vector<int> &com, int &d, stack<int> &S)
{
    dfn[u]=low[u]=++d;
    S.push(u);
    for(int v: E[u])
    {
        if( !dfn[v] )
            tarjan_scc(v, E, dfn, low, com, d, S);
        if ( !com[v] )
            low[u]=min(low[u], low[v]);
    }
    if( dfn[u]==low[u] )
        for(bool f=true; f; S.pop())
        {
            f=S.top()!=u;
            com[S.top()]=u;
        }
}

void dfs(int u, const vector<vector<int>> &E, vector<bool> &used)
{
    used[u]=true;
    for(int v: E[u])
        if(!used[v])
            dfs(v, E, used);
}

int sol()
{
    int n, m;
    scanf("%d%d", &n, &m);
    vector<vector<int>> E(n+1);
    for(int i=1; i<=m; i++)
    {
        int u, v;
        scanf("%d%d", &u, &v);
        E[u].push_back(v);
    }
    stack<int> S;
    vector<int> dfn(n+1), low(n+1), com(n+1);
    int d=0;
    for(int i=1; i<=n; i++)
        if(!dfn[i])
            tarjan_scc(i, E, dfn, low, com, d, S);
    vector<vector<int>> E2(n+1);
    vector<int> in(n+1);
    vector<bool> lead(n+1);
    for(int i=1; i<=n; i++)
    {
        int u=com[i];//index of scc that contains vertex i
        lead[u]=true;
        for(int j: E[i])
        {
            int v=com[j];
            if(u==v)//vertex i and vertex j are in same scc
                continue;
            E2[u].push_back(v);
            in[v]++;
        }
    }
    int x=-1;
    for(int i=1; i<=n; i++)
        if(lead[i] && in[i]==0)
        {
            if(x!=-1)
                return 0;
            x=i;
        }
    vector<bool> used(n+1);
    dfs(x, E2, used);
    for(int i=1; i<=n; i++)
        if(lead[i] && !used[i])
            return 0;
    int res=0;
    for(int i=1; i<=n; i++)
        if(com[i]==x)
            res++;
    return res;
}

int main()
{
    int T;
    for(scanf("%d", &T); T>0; T--)
        printf("%d\n", sol());
}
